package com.android.calculator3.test;

import com.robotium.solo.Solo;
import android.content.Intent;
import android.test.ActivityInstrumentationTestCase2;
import android.test.suitebuilder.annotation.Smoke;
import android.view.KeyEvent;
import android.widget.GridView;

import com.android.calculator3.Calculator;

public class BP14Test0 extends
		ActivityInstrumentationTestCase2<Calculator> {

	private Solo driver;

	//-- test cases -----------------------------------//
	
 	/**
	 * Default Testcase
	 *
	 * 
	 */
	@Smoke 
	public void test_t0(){
		try {
			// Trigger web events
			driver.sendKey(Solo.MENU);
			driver.clickOnMenuItem("Clear history");
			driver.sleep(1000);
			driver.sleep(5000);
			assertEquals("", driver.getEditText(0).getText().toString());
			driver.sendKey(Solo.MENU);
			driver.clickOnMenuItem("Advanced panel");
			driver.sleep(1000);
			driver.clickOnButton("e");
			driver.clickOnButton("=");
			driver.sleep(5000);
			assertEquals((String)"2.71828183", driver.getEditText(0).getText().toString());
			driver.sendKey(Solo.MENU);
			driver.clickOnMenuItem("Clear history");
			driver.sleep(1000);
			driver.clickOnButton("1");
			driver.clickOnButton("0");
			driver.clickOnButton("0");
			driver.clickLongOnTextAndPress(java.util.regex.Pattern.quote("100"), 0);
			driver.clickOnButton("1");
			driver.clickOnButton("0");
			driver.clickOnButton("0");
			driver.clickLongOnTextAndPress(java.util.regex.Pattern.quote("100"), 2);


		} catch(Exception e){
			e.printStackTrace();
		}
	}

	//-------------------------------------------------//

	public BP14Test0(){
		super("com.android.calculator3", Calculator.class);
	}

	void EnableCheckbox(int index)
  	{
    	if(false==driver.isCheckBoxChecked(index))
    	{
      		driver.clickOnCheckBox(index);
    	}
  	}

  	void DisableCheckbox(int index)
  	{
    	if(true==driver.isCheckBoxChecked(index))
    	{
      		driver.clickOnCheckBox(index);
    	}
  	}

	@Override
	public void setUp() throws Exception {
	super.setUp();
		Intent i = new Intent();
	    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	    setActivityIntent(i);
		driver = new Solo(getInstrumentation(), getActivity());
		driver.sleep(1000);
	}


	@Override
	public void tearDown() throws Exception {
		// Robotium will finish all the activities that have been opened
		driver.finishOpenedActivities();
		super.tearDown();
	}
}